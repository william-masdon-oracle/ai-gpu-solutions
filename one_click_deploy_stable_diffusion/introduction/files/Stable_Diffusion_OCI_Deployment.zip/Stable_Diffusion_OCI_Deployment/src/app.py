import torch
from diffusers import StableVideoDiffusionPipeline
from diffusers.utils import export_to_video
import gradio as gr
from PIL import Image
import numpy as np

# Release all unoccupied cached memory
torch.cuda.empty_cache()

# Check if GPU is available
DEVICE = "cuda" if torch.cuda.is_available() else "cpu"
print(f"Using device: {'GPU' if DEVICE == 'cuda' else 'CPU'}")
MODEL_ID = "stabilityai/stable-video-diffusion-img2vid"
pipe = StableVideoDiffusionPipeline.from_pretrained(
    MODEL_ID,
    torch_dtype=torch.float16 if DEVICE == "cuda" else torch.float32
).to(DEVICE)

# Define the video generation function
def generate_video(input_image):
    input_image = Image.fromarray(np.array(input_image))
    video = pipe(input_image, num_frames=12)
    frames = video.frames[0]
    video_path = export_to_video(frames)
    return video_path 

# Create the Gradio interface
demo = gr.Interface(
    fn=generate_video,
    inputs=gr.Image(type="pil", label="Upload Image"),
    outputs=gr.Video(label="Generated Video"),
    title="Stable Video Diffusion Demo",
    description="Upload an image to generate a short AI-generated video using Stable Video Diffusion.",
    allow_flagging="never"
)

# Start the Gradio app
if __name__ == "__main__":
    demo.launch(server_name="0.0.0.0", share=True, server_port=7860)